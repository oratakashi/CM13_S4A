Advan S4A
=========================

Basic   | Spec Sheet
-------:|:-------------------------
CPU     | 1.2GHz Dual-Core MTK6572 Overclocked 1.4GHz
GPU     | Mali 400 MP
Memory  | 512MB RAM
Shipped Android Version | 4.2.2
Current Stable Android Version | 5.1.1
Current Android Version | 6.0.1
Storage | 4GB
Battery | 1300 mAh
Display | 4" 480x800 px
Camera  | 5.0MPx.


This branch is for building CyanogenMod 13.0 ROM.

Whats Working :
===============

Hardware   | Working
-------:|:-------------------------
Wifi     | Yes 
Bluetoth | Yes
Sensor  | Yes
Camera | No
Vidio Recording | No
Vidio Encoding | Yes
VPN | Yes
Hostspot | Yes
RIL | Yes

